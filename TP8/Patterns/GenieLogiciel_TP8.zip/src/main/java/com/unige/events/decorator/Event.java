package com.unige.events.decorator;

public interface Event {
    String getDetails();
}